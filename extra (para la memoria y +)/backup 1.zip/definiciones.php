<?php

// Dominio donde está la aplicación.
if(!defined("DOMINIO"))
	define("DOMINIO", "localhost");

// Carpeta donde está la aplicación
if(!defined("PATH"))
	define("PATH", "/");